package com.example.healthnews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Intent
import android.net.Uri


//Point d'entrée de l'application
class MainActivity : AppCompatActivity() {


    val adapter by lazy {

        ArticleAdapter {
            // when the user clicks on an article, redirects to article link
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(it.link))
            startActivity(browserIntent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val articlesList = listOf(

            Article(
                title = "Facteurs de risque de grossesse à risque",
                pictureUrl = "https://resize1.prod.docfr.doc-media.fr/rcrop/480,280,center-middle/img/var/doctissimo/storage/images/fr/www/grossesse/sante-et-grossesse/maladie-et-grossesse/grossesse-a-risque/1681811-1-fre-FR/grossesse-a-risque.jpg",
                link = "https://www.msdmanuals.com/fr/accueil/probl%C3%A8mes-de-sant%C3%A9-de-la-femme/grossesse-%C3%A0-risque/facteurs-de-risque-de-grossesse-%C3%A0-risque"
            ),
            Article(
                title = "La protection des femmes enceintes et les risques liés à la grossesse ",
                pictureUrl = "https://www.defenseurdesdroits.fr/sites/default/files/carousel_grossesse_2022_006.jpg",
                link = "https://travail-emploi.gouv.fr/sante-au-travail/statut-des-travailleurs-et-dispositions-particulieres/article/la-protection-des-femmes-enceintes-et-les-risques-lies-a-la-grossesse?TSPD_101_R0=087dc22938ab20008658c3c378dcbf21216390ecb334ebcf33ffb4ec43bcde99ef7db0dea5aaca74081aee6bb5143000a098b86f1899565b1c1622de3e0c9678dc12b5b0b427a298370dfcd057a7b899d238828e1c1215d2f728d6e297a4dd21"
            ),
            Article(
                title = "30 choses que vous devriez faire pendant votre grossesse",
                pictureUrl = "https://bebesetmamans.20minutes.fr/images/00_PHOTOS_ARTICLES/7186-30-choses-a-faire-pendant-grossesse_2.jpg",
                link = "https://bebesetmamans.20minutes.fr/grossesse/premier-trimestre/7186-30-choses-a-faire-pendant-grossesse/amp"
            ),
            Article(
                title = "Quels médicaments sans ordonnance éviter pendant la grossesse ?",
                pictureUrl = "https://i-sam.unimedias.fr/2021/06/04/automedication-femme-enceinte.jpg?auto=format%2Ccompress&crop=faces&cs=tinysrgb&fit=crop&h=591&w=1050",
                link = "https://www.santemagazine.fr/grossesse/grossesse-et-sante/enceinte-lautomedication-a-laquelle-vous-avez-droit-170788"
            ),
            Article(
                title = " La déclaration de grossesse",
                pictureUrl = "https://www.cprpsncf.fr/documents/20182/54828/illus-declaration-grossesse.jpg/3445b6cd-654f-4447-b71b-2cd168a2838a?t=1493107538188",
                link = "https://www.1000-premiers-jours.fr/fr/la-declaration-de-grossesse"
            ),
            Article(
                title = "Faire une chute enceinte : quels risques ?",
                pictureUrl = "https://cache.magicmaman.com/data/photo/w1000_c18/18s/tortueenvers.webp",
                link = "https://www.magicmaman.com/,faire-une-chute-enceinte-quels-risques,3441978.asp"
            ),
            Article(
                title = "Les bons réflexes à adopter quand on est enceinte",
                pictureUrl = "https://fac.img.pmdstatic.net/fit/http.3A.2F.2Fprd2-bone-image.2Es3-website-eu-west-1.2Eamazonaws.2Ecom.2Ffac.2F2020.2F12.2F17.2F92664d4e-c2fd-4adc-84b9-aea37addb71a.2Ejpeg/1200x1200/quality/80/crop-from/center/medicaments-pendant-la-grossesse-4-bons-reflexes-a-adopter-quand-on-est-enceinte.jpeg",
                link = "https://www.assurance-prevention.fr/bons-reflexes-grossesse.html"
            ),
        )

        val rv = findViewById<RecyclerView>(R.id.articles_list)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        adapter.submitList(articlesList)
    }
}