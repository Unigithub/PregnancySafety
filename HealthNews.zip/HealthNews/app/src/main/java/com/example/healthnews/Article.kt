package com.example.healthnews

data class Article(
    val title: String,
    val pictureUrl : String,
    val link : String
)