package com.example.healthnews

import android.text.TextUtils
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.healthnews.databinding.ItemArticleBinding


//fait le lien entre item_article.xml et article.kt. Va créer un item dans le recyclerview pour chacun
// des item dans la liste présente dans la MainActivity
class ArticleAdapter(val onClickListener : (Article) -> Unit) : ListAdapter<Article, ArticleAdapter.ArticleViewHolder>(DiffCallback()) {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder =
        ArticleViewHolder(
            ItemArticleBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ),onClickListener
        )

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        val phone = getItem(position)
        holder.bindTo(phone)
    }

    class ArticleViewHolder(
        val itemBinding: ItemArticleBinding,
        val onClickListener : (Article) -> Unit
    ) : RecyclerView.ViewHolder(itemBinding.root) {

        fun bindTo(article: Article) {
            itemBinding.articleTitle.text = article.title
            Glide.with(itemBinding.root.context).load(article.pictureUrl)
                .fitCenter()
                .into(itemBinding.articlePic)

            itemBinding.root.setOnClickListener {
                onClickListener.invoke(article)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Article>() {
        override fun areContentsTheSame(
            oldItem: Article,
            newItem: Article
        ): Boolean {
            return oldItem.link == newItem.link
        }

        override fun areItemsTheSame(
            oldItem: Article,
            newItem: Article
        ): Boolean {
            return oldItem == newItem
        }
    }
}